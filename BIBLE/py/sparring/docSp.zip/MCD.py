from sys import stdin

def MCD(i,j):                       #Cost         Time
    while j >= 2:                   #C1            n 
        c = i % j                   #C2            n-1
        i, j = j, c                 #C3            n-1
    if j == 0:                      #C4            1
        return i                    #C5            1
    else:                           #C6            1
        return 1                    #C7            1



def main():
    i, j = map(int, stdin.readline().strip().split())
    while i and j:
        print(MCD(i, j))
        i, j = map(int, stdin.readline().strip().split())
  

#main()

print(MCD(6, 12))