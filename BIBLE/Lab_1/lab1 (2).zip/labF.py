# F. Programe un método recursivo que invierta los números de un arreglo de enteros.
def invertir(s, index=0):
    if index < len(s)//2:
        elemento, s[-index-1] = s[-index-1], s[index]
        s[index], index = elemento, index+1
        invertir(s, index)

    return s


def main():
    s = [i for i in range(10)]
    print("Lista original:",s)
    print("Lista invertida:", invertir(s))


main()
