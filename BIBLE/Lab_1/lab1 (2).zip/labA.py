# A. Escriba una función recursiva que ordene de menor a mayor una lista de enteros basándose en la siguiente idea:
# coloque el elemento más pequeño en la primera ubicación, y luego ordene el resto del arreglo con una llamada
# recursiva.
from random import randint

SIZE = 10
SEED = 1e3


def minM(s, index):
    if index == len(s):
        return s
    else:
        minNum = min(s[index:])
        if minNum != s[index]:
            pos = s.index(minNum)
            s[index], s[pos] = s[pos], s[index]

            return minM(s, index + 1)
        else:

            return minM(s, index + 1)


def main():
    s = [randint(1, SEED) for i in range(randint(1, SIZE))]
    print(minM(s, 0))


main()
